package Test;
import java.util.Scanner;

public class Q2 {

	
	     public static void main(String[] args) 
	     {
	        
	        Scanner scanner = new Scanner(System.in);
	       
	        System.out.print("Enter a number: ");
	        int number = scanner.nextInt();
	        
	        // Call the method to print factors
	        printFactors(number);
	        
	        // Close the scanner
	        scanner.close();
	    }

	    // Method to print all factors of the number
	    public static void printFactors(int number) {
	        System.out.println("Factors of " + number + ":");
	        for (int i = 2; i <= number; i++) {
	            if (number % i == 0) {
	                System.out.println(i);
	            }
	        }
	    }
	}


