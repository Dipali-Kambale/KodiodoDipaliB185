package Test;

public class Q1 {

		private int id;
		private String name;
		private String address;
		private String dept;
		
		


		public Q1 (int id, String name,  String address, String dept)
		{
			this.id=id;
			this.name=name;
			this.dept=dept;
			this.address=address;
		}
		
		@Override
		public String toString() {
			return "Q1 [id=" + id + ", name=" + name +  ", address=" + address + ", dept=" + dept + "]";
		}

	}
	
	

	


