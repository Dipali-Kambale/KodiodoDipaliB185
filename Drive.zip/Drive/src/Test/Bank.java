package Test;

import Test.Bank;
import Test.Q3;
import java.util.Scanner;

public class Bank {
	
	public void reg(long n) throws Q3
	{
	
		
		
		
		if(n>=0) {
			System.out.println("Given no is Positive no.");
		}
		else {
			Q3 e= new Q3();
			throw e;
		}
		
			
		
	}

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter any no");
		int num=s.nextInt();
		Bank d=new Bank();
		try
		{
			d.reg(num);
			
		}
		catch(Q3 e)
		{
			System.out.println(e.getMessage());
		}
	
		
	}

}
