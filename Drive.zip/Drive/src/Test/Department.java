package Test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Department {
	
	private static final String[] Q1 = null;

	public static void main(String args[])
	{
		Map<Integer, Q1> ce=new HashMap<>();
		
		Q1 e1=new Q1(101,"pqr","pune","Hr Department");
		Q1 e2=new Q1(102,"xyz","pune","Hr Department");
		
		
		ce.put(101,e1);
		ce.put(102,e2);
		
		
       Map<Integer, Q1> etc=new HashMap<>();
		
		Q1 e3=new Q1(101,"abd","Mumbai","Technical Department");
		Q1 e4=new Q1(102,"xyz","Mumbai","Technical Department");
		
		etc.put(101,e3);
		etc.put(102,e4);
		
		
		
		
		System.out.println("Hr Department Employee Details ");
		Set<Integer> set=ce.keySet();
		Iterator<Integer>itr=set.iterator();
		
		while(itr.hasNext())
		{
			int key=itr.next();
			Q1 obj=ce.get(key);
			System.out.println(obj);
			
			
			
		}
		
		System.out.println("----------------------------------------------------");
		
		System.out.println("Technical Department Employee Details");
		Set<Integer> set1=etc.keySet();
		Iterator<Integer>itr1=set1.iterator();
		
		while(itr1.hasNext())
		{
			int key=itr1.next();
			Q1 obj=etc.get(key);
			System.out.println(obj);
			
			
		}
		
		
		
		
	}

}
