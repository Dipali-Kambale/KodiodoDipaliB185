package Test;

public class Q3 extends Exception {
	
	static String msg=" Given number is Negative";
	public Q3()
	{
		super(msg);
	}

}
